#!/sbin/sh
mount -o rw /product
rm -rf /external_sd/imeibackup
mkdir -p /external_sd/imeibackup/META-INF/com/google/android

if [[ $(ls /dev/block | grep mapper) ]] ; then PRODUCT_BUILD_PROP=/product/etc/build.prop && PRODUCT_LOCATION=/product ; fi
DEVICE_NAME=$(grep ro.product.product.name $PRODUCT_BUILD_PROP) && DEVICE_NAME=${DEVICE_NAME#*=} #unable to get the prop directly so fetch from build.prop instead

DATE=$(date +%Y-%m-%d)  #Append Date For Easier Reference

#Checking the existence of bootdevice paths
partdir=/dev/block/bootdevice/by-name

if [ ! -d $partdir ]; then
  partdir=/dev/block/by-name
fi

if [ ! -d $partdir ]; then
  abort "Failed unable to find the partition!";
fi

#Assert To Prevent Flashing Wrong IMEI(Incase You're dumb?)
echo 'ui_print (" ");
ui_print (" IMEI Restore Script By @isus203");
ui_print (" ");
ui_print (" Flashing Partitions .... ");
ui_print (" ");' >> /external_sd/imeibackup/META-INF/com/google/android/updater-script

echo "ui_print (\" Target CPU: Mediatek\");" >> /external_sd/imeibackup/META-INF/com/google/android/updater-script && echo "ui_print (\" Target Device:$DEVICE_NAME\");" >> /external_sd/imeibackup/META-INF/com/google/android/updater-script
echo "ui_print (\" Backup Date Is $DATE\");" >> /external_sd/imeibackup/META-INF/com/google/android/updater-script

echo 'package_extract_file("nvram.bin", "/dev/block/by-name/nvram");
package_extract_file("nvdata.img", "/dev/block/by-name/nvdata");
package_extract_file("persist.img", "/dev/block/by-name/persist");
package_extract_file("protect1.img", "/dev/block/by-name/protect1");
package_extract_file("protect2.img", "/dev/block/by-name/protect2");
package_extract_file("proinfo.img", "/dev/block/by-name/proinfo")
package_extract_file("nvcfg.img", "/dev/block/by-name/nvcfg");' >> /external_sd/imeibackup/META-INF/com/google/android/updater-script

echo 'ui_print (" ");
ui_print (" Flashed All Partitions! ");
ui_print (" ");
ui_print (" IMEI Should Hopefully Be Restored");
ui_print (" ");' >> /external_sd/imeibackup/META-INF/com/google/android/updater-script

cp /tmp/update-binary /external_sd/imeibackup/META-INF/com/google/android

for part in nvcfg nvdata persist protect1 protect2 proinfo; do dd if=$partdir/$part of=/external_sd/imeibackup/${part}.img; 
done

for part in nvram; do dd if=$partdir/$part of=/external_sd/imeibackup/${part}.bin; 
done

NAME_OF_ZIP="$DEVICE_NAME"-IMEI-Backup-"$DATE".zip

cd /external_sd/imeibackup
zip -r $NAME_OF_ZIP *
rm -rf META-INF
